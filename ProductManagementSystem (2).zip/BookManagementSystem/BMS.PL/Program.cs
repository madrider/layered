﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BMS.Entities;
using BMS.BLL;
using BMS.BookException;
namespace BMS.PL
{
    class Program
    {
        static void AddBook()
        {
            try
            {
                Book book = new Book();

                Console.WriteLine("Enter Book Code");
                book.ID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Book Name");
                book.Name = Console.ReadLine();
                Console.WriteLine("Enter Book Description");
                book.Description = Console.ReadLine();
                Console.WriteLine("Enter Book Price");
                book.Price = Convert.ToDouble(Console.ReadLine());

                if (BookBLL.AddBookBLL(book))
                {
                    Console.WriteLine("Book Added Successfully...");
                }
                else
                {
                    Console.WriteLine("Unable to Add Book ");
                }
            }
            catch (BookException.BookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void UpdateBook()
        {
            try
            {
                Book book = new Book();

                Console.WriteLine("Enter Book Code");
                book.ID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Book Name");
                book.Name = Console.ReadLine();
                Console.WriteLine("Enter Book Description");
                book.Description = Console.ReadLine();
                Console.WriteLine("Enter Book Price");
                book.Price = Convert.ToDouble(Console.ReadLine());

                if (BookBLL.UpdateBookBLL(book))
                {
                    Console.WriteLine("Book Updated Successfully...");
                }
                else
                {
                    Console.WriteLine("Unable to update Book ");
                }
            }
            catch (BookException.BookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void DeleteBook()
        {
            try
            {
                Console.WriteLine("Enter book ID for delete");
                int code = Convert.ToInt32(Console.ReadLine());

                bool status = BookBLL.DeleteBookBLL(code);

                if (status)
                {
                    Console.WriteLine("Book Deleted");
                }
                else
                {
                    Console.WriteLine("Unable to Delete Book");
                }
            }
            catch (BookException.BookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void GetAllBook()
        {
            try
            {
                List<Book> booklist = BookBLL.GetBooksBLL();

                if (booklist != null)
                {
                    Console.WriteLine("Code-->Name-->Price-->Description");
                    foreach (Book book in booklist)
                    {
                        Console.WriteLine(book.ID + "-->" + book.Name
                            + "-->" + book.Price + "-->" + book.Description);
                    }
                }
                else
                {
                    Console.WriteLine("No Books to Display");
                }
            }
            catch (BookException.BookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void SerachBookByCode()
        {
            try
            {
                Console.WriteLine("Enter book id for search");
                int code = Convert.ToInt32(Console.ReadLine());

                Book book = BookBLL.SearchBLL(code);

                if (book != null)
                {
                    Console.WriteLine("Book Information");
                    Console.WriteLine("Code = " + book.ID);
                    Console.WriteLine("Name = " + book.Name);
                    Console.WriteLine("Description = " + book.Description);
                    Console.WriteLine("Price = " + book.Price);
                }
                else
                {
                    Console.WriteLine("Book Not Available");
                }
            }
            catch (BookException.BookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void PrintMenu()
        {
            Console.WriteLine("\n***********Book Management Menu***********");
            Console.WriteLine("1. Add Book");
            Console.WriteLine("2. Update Book");
            Console.WriteLine("3. Delete Book");
            Console.WriteLine("4. List All Books");
            Console.WriteLine("5. Search Book by Code");
            Console.WriteLine("6. Exit");
            Console.WriteLine("******************************************\n");
        }

        static void Main(string[] args)
        {
            int choice;

            do
            {
                PrintMenu();
                Console.WriteLine("Enter you choice");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddBook();
                        break;

                    case 2:
                        UpdateBook();
                        break;

                    case 3:
                        DeleteBook();
                        break;

                    case 4:
                        GetAllBook();
                        break;

                    case 5:
                        SerachBookByCode();
                        break;

                    case 6:
                        return;

                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }
    }
}
