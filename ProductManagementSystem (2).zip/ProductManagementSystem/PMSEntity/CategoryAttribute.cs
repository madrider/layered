﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSEntity
{
    [AttributeUsage(AttributeTargets.Class,AllowMultiple=true )]
    public class CategoryAttribute:Attribute
    {
        //private string CatType;
        public string CategoryType { get; set; }
        public CategoryAttribute(string type)
        {

            CategoryType = type;
        }

    }
}
