﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using PMSEntity;
using PMSException;
namespace PMS_DAL
{
    /// <summary>
    /// Author: Capgemini
    /// Date Of Creation: 10-Nov-2017
    /// Description: To perform all Operations on Product Data
    /// </summary>
    public class ProductOperation
    {
      static List<Product> productList = new List<Product>();

      public bool AddProductDAL(Product newProduct)
      {
          bool isProductAdded = false;
          try
          {
              productList.Add(newProduct);
              isProductAdded = true;
          }
          catch (ProductException)
          {
              throw;
          }

          return isProductAdded;
      
      }
      public List<Product> DisplayProductDAL()
      {
    
          return productList;
      }
        /// <summary>
        /// To Delete a product from the list
        /// </summary>
        /// <param name="productToBeDeleted"></param>
        /// <returns></returns>
      public bool DeleteProductDAL(Product productToBeDeleted) 
      {
          try
          {
              productList.Remove(productToBeDeleted);
              return true;
          }
          catch (ProductException) { throw; }
      }
        /// <summary>
        /// To search the product based on the ProductId
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
         public Product SearchProductDAL(int productId)
      {
          try
          {
              Product searchedProduct = null;
              foreach (Product p in productList)
              {
                  if (p.ProductId == productId)
                      searchedProduct = p;
              }
              return searchedProduct;
          }
          catch (ProductException) { throw; }

      }

         public  bool UpdateProductDAL(Product prodToBeUpdated)
         {
             bool isProductUpdated = false;

             for (var i = 0; i < productList.Count; i++)
             {
                 if (productList[i].ProductId == prodToBeUpdated.ProductId)
                 {
                     productList[i].ProductName = prodToBeUpdated.ProductName ;
                     productList[i].Category = prodToBeUpdated.Category;
                     productList[i].Price = prodToBeUpdated.Price;
                     productList[i].ExpiryDate = prodToBeUpdated.ExpiryDate;

                     isProductUpdated = true;
                 }
             }

             return isProductUpdated;
         }

         public void SerializeProductDAL()
         {
             try
             {
                 FileStream fs = new FileStream("Product.dat", FileMode.Create, FileAccess.Write);
                 BinaryFormatter formatterObj = new BinaryFormatter();
                 formatterObj.Serialize(fs, productList);
                 fs.Close();             
             }
             catch (IOException) { throw; }
         
         }
        /// <summary>
        /// Author: Capgemini
        /// Date Of Creation: 13-Nov-2017
        /// Purpose: To retrieve Product List from the file using Deserialization
        /// </summary>
        /// <returns></returns>
         public List<Product> DeSerializeProductDAL()
         {
              List<Product> deserializedList = new List<Product>();
             try
             {
                 FileStream fs = new FileStream("Product.dat", FileMode.Open , FileAccess.Read);
                 BinaryFormatter formatterObj = new BinaryFormatter();
                
                deserializedList =(List<Product>) formatterObj.Deserialize(fs);
             }
             catch (IOException) { throw; }
             return deserializedList;
         }
    }
}
