﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSException
{
    /// <summary>
    /// Author: Capgemini
    /// Date Of Creation: 10-Nov-2017
    /// Description:Custom Exception class to handle exceptions thrown in PMS
    /// </summary>
    public class ProductException:ApplicationException 
    {
        public ProductException() : base() { }

        public ProductException(string errorMsg) : base(errorMsg ) { }

        public ProductException(string errMsg, Exception innerException) :
            base(errMsg, innerException) { }
    }
}
