﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.IO;
using PMSEntity;
using PMSException;
using PMS_DAL;

namespace PMS_BLL
{
    /// <summary>
    /// Author: Capgemini
    /// Date Of Creation: 10-Nov-2017
    /// Description: To perform all Validations on Product Data
    /// </summary>
    public class ProductValidation
    {
        static List<Product> productList = new List<Product>();
        ProductOperation operationObj = new ProductOperation();

        /// <summary>
        /// Method to validate the Product Data/Details
        /// </summary>
        /// <param name="newProduct"></param>
        /// <returns></returns>
        public bool validateProduct(Product newProduct)
        {
            bool isValidProduct = true;
            StringBuilder sbErrorMsg = new StringBuilder();


            if (!((newProduct.ProductId >= 100) && (newProduct.ProductId <= 999)))
            {
                isValidProduct = false;
                sbErrorMsg.Append("Product Id should have exactly 3 digits");
            }

            if (!Regex.IsMatch(newProduct.ProductName, "^[A-Za-z]+"))
            {
                isValidProduct = false;
                sbErrorMsg.Append("Product Name should have only characters");
            }
            if (newProduct.ExpiryDate <= DateTime.Now)
            {
                isValidProduct = false;
                sbErrorMsg.Append("Expiry Date should be greater than the current date ");
            }

            if (!((newProduct.Category.ToLower() == "food") || (newProduct.Category.ToLower() == "beverages")))

            {
                isValidProduct = false;
                sbErrorMsg.Append("Category should be Food or Beverages ");
       
            }
            if (!isValidProduct)
            {
                throw new ProductException(sbErrorMsg.ToString());
            }
            return isValidProduct;

        }

        public bool AddProductBLL(Product newProduct)
        {
        bool isAdded = false;
        try
        {
            if (validateProduct(newProduct))
                isAdded = operationObj.AddProductDAL(newProduct);
            else throw new ProductException("Product Details Could not be added");

        }
        catch (ProductException ex)
        {
            throw ex;
        }
        return isAdded;
        }

        public List<Product> DisplayProductBLL()
        {
            List<Product> pList = new List<Product>();
            try
            {
                pList = operationObj.DisplayProductDAL();
                if (pList.Count  != 0)
                {
                    productList = pList;
                }
                else
                    throw new ProductException("No Product to Display");
            }
            catch (ProductException ex)
            { throw ex; }
            return productList;
        }
        public  bool DeleteProduct(int ProductID)
        {
            bool ProductDeleted = true;
            Product ProductToBeDeleted = null;
          //  ProductOperation OperationObj = new ProductOperation();
            try
            {
                //Search Product in the records
                ProductToBeDeleted = operationObj.SearchProductDAL(ProductID);

                //If Product is not null delete Product otherwise raise exception
                if (ProductToBeDeleted != null)
                {
                    ProductDeleted = operationObj .DeleteProductDAL(ProductToBeDeleted);
                }
                else
                {
                    ProductDeleted = false;
                    throw new ProductException("Product Info does not exist to delete");
                }
            }
            catch (ProductException p)
            {
                throw p;
            }
            catch (Exception e)
            {
                throw e;
            }

            return ProductDeleted;
        }

        //Function to search Product Info using Product ID
        public  Product SearchProductBL(int ProductID)
        {
            Product ProductSearched = null;
            //ProductOperation OperationObj = new ProductOperation();
            try
            {
                //Searching Product
                ProductSearched = operationObj.SearchProductDAL(ProductID);

                //If searched Product is null raise exception
                if (ProductSearched == null)
                {
                    throw new ProductException("Product Info does not exist!");
                }
            }
            catch (ProductException p)
            {
                throw p;
            }
            catch (Exception e)
            {
                throw e;
            }

            return ProductSearched;
        }

        //Function to update Product
        public  bool UpdateProduct(Product ProductToBeUpdated)
        {
            bool ProductUpdated = true;
            ProductOperation OperationObj = new ProductOperation();
            try
            {
                //Searching Product, if found update or raise exception
                if (OperationObj .SearchProductDAL(ProductToBeUpdated.ProductId) != null)
                {
                    //validating Product, if valid update o.w. raise exception
                    if (validateProduct(ProductToBeUpdated))
                    {
                        ProductUpdated = operationObj.UpdateProductDAL(ProductToBeUpdated);
                    }
                    else
                    {
                        ProductUpdated = false;
                        throw new ProductException("Product Info is not updated because it is not valid!");
                    }
                }
                else
                {
                    ProductUpdated = false;
                    throw new ProductException("Product id not exists for update!");
                }
            }
            catch (ProductException p)
            {
                throw p;
            }
            catch (Exception e)
            {
                throw e;
            }

            return ProductUpdated;
        }

        public void SerializeProducBL()
        {
            try
            {
                if (productList.Count != 0)
                {
                    operationObj.SerializeProductDAL();
                }
                else throw new ProductException("No Data to be Serialized");
            }
            catch (ProductException e) { throw e; }
            catch (IOException e) { throw e; }
        }
        public List<Product> DisplayFromFile()
        {
            List<Product> listFromFile = new List<Product>();
            try
            {
                listFromFile =operationObj .DeSerializeProductDAL();
                if (listFromFile.Count == 0)
                   throw new ProductException("No data to be displayed from file");

            }
            catch (ProductException e) { throw e; }
            catch (IOException e) { throw e; }
            return listFromFile;

        }
    }
}
