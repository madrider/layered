﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_Exception
{
    /// <summary>
    /// Author:srividhya
    /// Desc:To create a custom exception class that will handle all the exception in the application.
    /// Doc:2nd march 2018
    /// </summary>
    public class EmployeeException:ApplicationException
    {
        public EmployeeException() : base() { }
        public EmployeeException(string errormessage) : base(errormessage) { }
    }
}
