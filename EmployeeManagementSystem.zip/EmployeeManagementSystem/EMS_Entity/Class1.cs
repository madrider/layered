﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_Entity
{
    /// <summary>
    /// Author:SriVidhya
    /// Desc:Entity Class to get and set the properties of employee 
    /// Date of creation:2nd march 2018
    /// </summary>
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string Department { get; set; }
        public string  MobileNo{ get; set; }
        public string EmailId { get; set; }
        public string Location { get; set; }
    }
}
