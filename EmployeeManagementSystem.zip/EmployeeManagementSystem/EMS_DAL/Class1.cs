﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_Entity;
using EMS_Exception;

namespace EMS_DAL
{
    /// <summary>
    /// Author:srividhya
    /// Desc:To persorm all the operation on the Employee
    /// </summary>
    public class EmployeeOperation
    {
        static List<Employee> employeeList = new List<Employee>();
        public bool AddEmployee_DAL(Employee newEmp)
        {
            bool isEmpAdded = false;
            try
            {
                employeeList.Add(newEmp);
                isEmpAdded = true;
            }
            catch (EmployeeException)
            { throw; }
            return isEmpAdded;
        
        }
        public List<Employee> DisplayEmployee_DAL()
        {
            try { return employeeList; }
            catch(EmployeeException) { throw; }
        }
    }
}
