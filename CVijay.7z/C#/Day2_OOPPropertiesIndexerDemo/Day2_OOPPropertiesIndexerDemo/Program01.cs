﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPPropertiesIndexerDemo
{
    class Employee
    {
        int id;
        string name;
        double salary;

        public int EmpID
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }
        }

        public string EmpName
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public double Salary
        {
            get
            {
                return salary;
            }

            set
            {
                if (value <= 0)
                {
                    salary = 0;
                }
                else
                {
                    salary = value;
                }
            }
        }
    }
    class Program01
    {
        static void Main(string[] args)
        {
            //Object Intializer 
            Employee objEmployee = new Employee()
            {
                EmpID = 1991,
                EmpName = "Vijay",
                Salary = -999.99
            };

            Console.WriteLine("Employee Information");
            Console.WriteLine("Id = "+objEmployee.EmpID);
            Console.WriteLine("Name = "+objEmployee.EmpName);
            Console.WriteLine("Salary = "+objEmployee.Salary);
        }
    }
}
