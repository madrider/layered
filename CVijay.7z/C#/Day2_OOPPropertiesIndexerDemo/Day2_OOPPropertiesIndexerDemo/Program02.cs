﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPPropertiesIndexerDemo
{
    class Books
    {
        int code;
        string name;
        float price;

        public Books(int code, string name)
        {
            this.code = code;
            this.name = name;
        }

        //readonly property
        public int BookCode
        {
            get { return code; }
        }

        public string BookName
        {
            get { return name; }
        }

        //Write Only Property
        public float BookPrice
        {
            set
            {
                price = value;
            }
        }

        public float getPrice()
        {
            return price;
        }
    }
    class Program02
    {
        static void Main(string[] args)
        {
            Books objBook = new Books(486, "Asp.net MVC");
            objBook.BookPrice = 567.99F;

            Console.WriteLine("Book Information");
            Console.WriteLine("Code = "+objBook.BookCode);
            Console.WriteLine("Name = "+objBook.BookName);
            Console.WriteLine("Price = "+objBook.getPrice());
        }
    }
}
