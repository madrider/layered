﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPPropertiesIndexerDemo
{
    class Product
    {
        int _code;
        string _name;

        public int ProductCode
        {
            get
            {
                return _code;
            }

            set
            {
                _code = value;
            }
        }

        public string ProductName
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Product prod = new Product();
            prod.ProductCode = 1001;
            prod.ProductName = "Keyboard";

            Console.WriteLine("Product Details");
            Console.WriteLine("Code = "+prod.ProductCode);
            Console.WriteLine("Name = "+prod.ProductName);
        }
    }
}
