﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPPropertiesIndexerDemo
{
    //Auto-Implemented Property
    class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public string EmailAddress { get; set; }
        public float Marks { get;private set; }

        public void DisplayStudent()
        {
            Console.WriteLine("Student Details");
            Console.WriteLine("ID = "+StudentID);
            Console.WriteLine("Name = "+StudentName);
            Console.WriteLine("Email = "+EmailAddress);
            Marks = 89.77F;
            Console.WriteLine("Marks = "+Marks);
        }
    }

    class Program03
    {
        static void Main(string[] args)
        {
            Student objStud = new Student()
            {
                StudentID = 1987,
                StudentName = "Aniket",
                EmailAddress = "aniket@gmail.com",
               // Marks = 89.99F
            };

            objStud.DisplayStudent();
        }
    }
}
