﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPPropertiesIndexerDemo
{
    //Indexer Demo
    class Sample
    {
        string[] cities;

        public Sample(int size)
        {
            cities = new string[size];
        }

        //Indexer to Access the Array
        public string this[int index]
        {
            get
            {
                return cities[index];
            }

            set
            {
                cities[index] = value;
            }
        }
    }
    class Program04
    {
        static void Main(string[] args)
        {
            Sample obj = new Sample(5);

            obj[0] = "Mumbai";
            obj[1] = "Chennai";
            obj[2] = "Delhi";
            obj[3] = "Pune";
            obj[4] = "Hyderabad";

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(obj[i]);
            }
           
        }
    }
}
