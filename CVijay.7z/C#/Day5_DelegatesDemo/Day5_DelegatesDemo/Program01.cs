﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_DelegatesDemo
{
    //Delegate Declaration
    public delegate int 
        ArithematicDelegate1(int x, int y);

    public delegate double
        ArithematicDelegate2(double x, double y);
    class Program01
    {
        //Delegate Method Declaration
        public int Sum(int x, int y)
        {
            return x + y;
        }

        public double Divide(double x,double y)
        {
            return x / y;
        }

        static void Main(string[] args)
        {
            //Intializing Delegate
            Program01 obj = new Program01();

            ArithematicDelegate1 del1 = new
                ArithematicDelegate1(obj.Sum);

            ArithematicDelegate2 del2 = new
                ArithematicDelegate2(obj.Divide);

            int result1 = del1(10, 3);
            double result2 = del2.Invoke(10.88, 5.2);

            Console.WriteLine("Result 1= "+result1);
            Console.WriteLine("Result 2= "+result2);
        }
    }
}
