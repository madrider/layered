﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_DelegatesDemo
{
    //Lambda Expression Demo
    class Program07
    {
        static void Main(string[] args)
        {
            MyDelegate obj1 = 
                ()=>  Console.WriteLine("This is an Example of Lambda Expression");
            obj1();
            ArithematicDelegate1 obj2 = (x, y) => { return x + y; };
            Console.WriteLine("Sum = "+obj2(10,6));
        }
    }
}
