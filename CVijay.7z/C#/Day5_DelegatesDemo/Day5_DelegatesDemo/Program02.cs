﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_DelegatesDemo
{
    //generic delegate demo
    class Program02
    {
        //generic delegate
        public delegate T MyGenericDelegate<T>(T x, T y);

        //Delegate Method Declaration
        public static int Sum(int x, int y)
        {
            return x + y;
        }

        public static double Divide(double x, double y)
        {
            return x / y;
        }

        static void Main(string[] args)
        {
            MyGenericDelegate<int> del1 =
                new MyGenericDelegate<int>(Sum);

            MyGenericDelegate<double> del2 =
                new MyGenericDelegate<double>(Divide);

            Console.WriteLine("Result 1= "+
                del1(10,8));

            Console.WriteLine("Result 2= "+
                del2(88.77,11.2));
        }
    }
}
