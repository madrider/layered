﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_DelegatesDemo
{
    public delegate void MyCollectionDelegate();
    //Publisher
    class MyCollection
    {
        List<string> items = new List<string>();

        public event MyCollectionDelegate ItemAdded;

        public void OnAdded()
        {
            if (ItemAdded != null)
                ItemAdded();
        }

        public void AddItem(string value)
        {
            items.Add(value);
            OnAdded();
        }
        
    }
    class Program08
    {
        public static void Confirmation()
        {
            Console.WriteLine("Item Added Successfully");
        }
        static void Main(string[] args)
        {
            MyCollection obj = new MyCollection();
            obj.ItemAdded += new MyCollectionDelegate(Confirmation);
            obj.AddItem("Hello");
            obj.AddItem("Plane");
        }
    }
}
