﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_DelegatesDemo
{
    public delegate bool IsPromotable(Employee employee);
    public class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Salary { get; set; }        
        public int Experience { get; set; }

        public static void PromoteEmployees
            (List<Employee> emplist,IsPromotable eligiblePromotion)
        {
            foreach (Employee emp in emplist)
            {
                if (eligiblePromotion(emp))
                {
                    Console.WriteLine(emp.Name+" is promoted...");
                }
            }
        }
    }
    class Program04
    {
        public static bool Promote(Employee emp)
        {
            if (emp.Salary >= 5000)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static void Main(string[] args)
        {
            List<Employee> employeelist = new List<Employee>()
            {
                new Employee { ID=1001,Name="Anil",Salary=8900,Experience=4 },
                new Employee { ID=1002,Name="Ganesh",Salary=9900,Experience=5 },
                new Employee { ID=1003,Name="Suresh",Salary=10000,Experience=6 },
                new Employee { ID=1004,Name="Malcolm",Salary=4700,Experience=3 },
                new Employee { ID=1005,Name="Vijay",Salary=7800,Experience=4 },
            };

            IsPromotable objDel = new IsPromotable(Promote);

            Employee.PromoteEmployees(employeelist,objDel);

        }
    }
}
