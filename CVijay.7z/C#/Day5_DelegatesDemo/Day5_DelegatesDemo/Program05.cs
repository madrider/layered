﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_DelegatesDemo
{
    //Event Demo
    delegate void ArithematicHandler(int x, int y);

    class Calculator
    {
        //event
        public event ArithematicHandler Operation;

        public void Sum(int x, int y)
        {
            Console.WriteLine("Sum = "+(x+y));
        }

        public void OnOperation(int x, int y)
        {
            if (Operation != null)
                Operation(x, y);
        }
    }

    class Program05
    {
        static void Main(string[] args)
        {
            Calculator obj = new Calculator();
           // obj.Operation += new ArithematicHandler(obj.Sum);
            obj.OnOperation(10, 20);
        }
    }
}
