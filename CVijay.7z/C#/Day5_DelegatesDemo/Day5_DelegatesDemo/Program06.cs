﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_DelegatesDemo
{
    class Program06
    {
        //Anonymous Method
        static void Main(string[] args)
        {
            MyDelegate del1 = delegate () 
            {
                Console.WriteLine("Example of Anonymous Method");
            };

            ArithematicDelegate1 del2 = delegate (int x, int y)
             {
                 return x + y;
             };

            del1();
            int sum = del2(10, 6);
            Console.WriteLine("Sum = "+sum);
        }
    }
}
