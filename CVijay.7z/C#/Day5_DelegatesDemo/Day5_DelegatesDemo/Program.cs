﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_DelegatesDemo
{ //Delegate Declaration
    public delegate void MyDelegate();
    class Program
    {
       

        //Delegate Method Declaration
        public static void Display()
        {
            Console.WriteLine("Inside Display()");
        }

        public static void Show()
        {
            Console.WriteLine("Inside Show()");
        }

        public static void DisplayMessage(string msg)
        {
            Console.WriteLine(msg);
        }
        static void Main(string[] args)
        {
            //Intializing the Delegate
            MyDelegate obj1 = new
                MyDelegate(Display);

            MyDelegate obj2 = new
                MyDelegate(Show);

            //Invoking Delegate
            obj1();
            obj2();

            obj1.Invoke();
            obj2.Invoke();

            //MyDelegate obj3 = new
            //    MyDelegate(DisplayMessage);
        }
    }
}
