﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_DelegatesDemo
{
    //Multicast Delegates Demo
    class Program03
    {
        public delegate void 
            OperationDelegate(double x, double y);
        static void Sum(double x, double y)
        {
            Console.WriteLine("Sum = " + (x + y));
        }
        static void Subtract(double x, double y)
        {              
            Console.WriteLine("Difference = " + (x - y));
        }
        static void Multiply(double x, double y)
        {
            Console.WriteLine("Product = " + (x * y));
        }
        static void Divide(double x, double y)
        {
            Console.WriteLine("Quotient = " + (x / y));
        }
        static void Main(string[] args)
        {
            OperationDelegate obj = new
                OperationDelegate(Subtract);
            obj += new OperationDelegate(Sum);
            obj += new OperationDelegate(Divide);
            obj += new OperationDelegate(Multiply);

            obj(10, 3);//Calling Multicast Delegate
        }
    }
}
