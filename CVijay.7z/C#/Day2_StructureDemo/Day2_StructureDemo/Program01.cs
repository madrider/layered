﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_StructureDemo
{
    enum RequestType
    {
        Basic=500,
        Intermediate=1000,
        Expert=2500
    }

    class Ticket
    {
        public int ID { get; set; }
        public string TaskName { get; set; }
        public RequestType RequestType { get; set; }
    }
    class Program01
    {
        static void Main(string[] args)
        {
            Ticket obj = new Ticket()
            {
                ID = 1001,
                TaskName = "Installation of Windows",
                RequestType = RequestType.Intermediate
            };

            Console.WriteLine("Ticket Information");
            Console.WriteLine("Id = "+obj.ID);
            Console.WriteLine("Task = "+obj.TaskName);
            Console.WriteLine("Type = "+obj.RequestType);
            Console.WriteLine("Charges = "+(int)obj.RequestType);
        }
    }
}
