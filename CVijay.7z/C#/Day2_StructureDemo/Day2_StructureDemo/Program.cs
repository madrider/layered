﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_StructureDemo
{
    struct Employee
    {
        private int Id;
        private string name;

        public Employee(int id, string name)
        {
            this.Id = id;
            this.name = name;
        }

        public void Display()
        {
            Console.WriteLine("Employee Information");
            Console.WriteLine("Id = "+Id);
            Console.WriteLine("Name = "+name);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Employee obj = new Employee(101,"Vijay");

            obj.Display();
        }
    }
}
