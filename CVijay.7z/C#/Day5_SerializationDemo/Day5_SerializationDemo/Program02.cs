﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Day5_SerializationDemo
{
    [Serializable]
    class ShoppingCartItem :IDeserializationCallback
    {
        public int productid;
        public decimal price;
        public int quantity;

        [NonSerialized]
        public decimal total;

        public ShoppingCartItem(int _id, decimal _price, int _qty)
        {
            productid = _id;
            price = _price;
            quantity = _qty;
            total = price * quantity;
        }

        public void OnDeserialization(object sender)
        {
            total = price * quantity;
        }
    }

    class Program02
    {
        static void SerializaObject(ShoppingCartItem obj)
        {
            FileStream fstream = new FileStream(@"D:\Sample\Shopping.dat",
                FileMode.Create, FileAccess.Write);

            BinaryFormatter formatter = new BinaryFormatter();

            formatter.Serialize(fstream, obj);

            Console.WriteLine("Object Serialized Successfully...");
            fstream.Close();
        }

        static void DeserializaObject()
        {
            FileStream fstream = 
                new FileStream(@"D:\Sample\Shopping.dat",
                FileMode.Open, FileAccess.Read);

            BinaryFormatter formatter = new BinaryFormatter();

            ShoppingCartItem item =
                (ShoppingCartItem)formatter.Deserialize(fstream);

            Console.WriteLine("Objects Information");
            Console.WriteLine("{0} {1} {2} {3}",
                item.productid,item.price,item.quantity,
                item.total);

            fstream.Close();
        }

        static void Main(string[] args)
        {
            ShoppingCartItem objItem = 
                new ShoppingCartItem(101, 20, 8);
            SerializaObject(objItem);
            DeserializaObject();
        }
    }
}
