﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Day5_SerializationDemo
{
    [Serializable]
    class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public double Salary { get; set; }
    }

    class Program
    {
        //Using Binary Serialization
        static void SerializaData()
        {
            Employee emp = new Employee
            { ID = 1001, Name = "Vijay",
                Salary = 234.99 };

            FileStream fstream = 
                new FileStream(@"D:\Sample\Binary.txt",
                FileMode.Create, FileAccess.Write);

            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(fstream, emp);

            fstream.Close();
            Console.WriteLine("Serialization Done....");
        }

        static void DeserializeData()
        {
            FileStream fstream = new
                FileStream(@"D:\Sample\Binary.txt",
                FileMode.Open, FileAccess.Read);

            BinaryFormatter formatter = new BinaryFormatter();

            Employee emp = (Employee)formatter.Deserialize(fstream);

            Console.WriteLine("\nDeserializaton Done..");
            Console.WriteLine("Id = "+emp.ID);
            Console.WriteLine("Name = "+ emp.Name);
            Console.WriteLine("Salary = "+emp.Salary);

            fstream.Close();
        }
        static void Main(string[] args)
        {
            SerializaData();
            DeserializeData();
        }
    }
}
