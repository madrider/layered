﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Runtime.Serialization.Formatters.Soap;
using System.IO;

namespace Day5_SerializationDemo
{
    class Program01
    {
        //using SOAP Serialization
        static void SerializeData()
        {
            Employee emp = new Employee
            {
                ID = 101,
                Name = "Ajay",
                Salary = 1234.88
            };

            FileStream fstream = new 
                FileStream(@"D:\Sample\SOAP.txt",
            FileMode.Create, FileAccess.Write);

            SoapFormatter formatter = new SoapFormatter();
            formatter.Serialize(fstream, emp);

            Console.WriteLine("SOAP Serialization Done...");
            fstream.Close();
        }

        static void DeserializaData()
        {
            FileStream fstream = new 
                FileStream(@"D:\Sample\SOAP.txt",
            FileMode.Open, FileAccess.Read);

            SoapFormatter formatter = new SoapFormatter();

            Employee emp = (Employee)formatter.Deserialize(fstream);

            Console.WriteLine("\nSOAP Deserializaton Done..");
            Console.WriteLine("Id = " + emp.ID);
            Console.WriteLine("Name = " + emp.Name);
            Console.WriteLine("Salary = " + emp.Salary);

            fstream.Close();
        }

        static void Main(string[] args)
        {
            SerializeData();
            DeserializaData();
        }
    }
}
