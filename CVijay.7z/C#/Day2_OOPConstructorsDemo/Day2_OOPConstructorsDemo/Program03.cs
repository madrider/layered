﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPConstructorsDemo
{
    class StaticSample
    {
        static StaticSample()//Static Constructor
        {
            Console.
                WriteLine("Static Constructor Called..");
        }

        public StaticSample()
        {
            Console.
                WriteLine("Default Constructor Called...");
        }
    }
    class Program03
    {
        static void Main(string[] args)
        {
            StaticSample obj = new StaticSample();
        }
    }
}
