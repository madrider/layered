﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPConstructorsDemo
{
    class Sample
    {
        public Sample()//Default Constructor 
        {
            Console.WriteLine("Constructor Called...");
            Console.WriteLine("Object Created.....");
        }

        public void DisplayMessage()
        {
            Console.WriteLine("Have a Nice Day.....");
        }

        ~Sample()//Destructor
        {
            Console.WriteLine("Destructor Called...");
            Console.WriteLine("Object Destroyed....");
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Sample objSample = new Sample();
            objSample.DisplayMessage();
        }
    }
}
