﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPConstructorsDemo
{
    //Example of Parameterized Constructor
    class Person
    {
        string firstname, lastname;

        public Person(string fname, string lname)
        {
            firstname = fname;
            lastname = lname;
        }

        public void DisplayFullName()
        {
            Console.WriteLine("Full Name ="+firstname+lastname);
        }

        public override string ToString()
        {
            return string.Format("Full Name = {0} {1}",firstname,lastname);
        }
    }
    class Program01
    {
        static void Main(string[] args)
        {
            Person person1 = new Person("Aniket", "Raut");
            person1.DisplayFullName();

            Person person2 = new Person("Vijay", "Vishwakarma");
            Console.WriteLine(person2.ToString());

            //Error as no default Constructor is defined
            //Person person3 = new Person();
            //person2.DisplayFullName();
        }
    }
}
