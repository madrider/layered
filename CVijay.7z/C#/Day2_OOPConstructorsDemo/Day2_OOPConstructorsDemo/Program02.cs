﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPConstructorsDemo
{
    //Constructor Overloading Demo
    class Rectangle
    {
        int length, bredth;

        public Rectangle()
        {
            length = 5;
            bredth = 3;
        }

        public Rectangle(int x)
        {
            length = bredth = x;
        }

        public Rectangle(int len, int bred)
        {
            length = len;
            bredth = bred;
        }

        public int Area()
        {
            return length * bredth;
        }
    }
    class Program02
    {
        static void Main(string[] args)
        {
            Rectangle rect1 =new Rectangle();
            Console.WriteLine("Area = "+rect1.Area());

            Rectangle rect2 = new Rectangle(16);
            Console.WriteLine("Area = "+rect2.Area());

            Rectangle rect3 = new Rectangle(3, 6);
            Console.WriteLine("Area = "+rect3.Area());
        }
    }
}
