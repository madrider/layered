﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_GenericDemo
{
    class DaysofWeek
    {
        string[] days =
            {"Sunday","Monday","Tuesday","Wednesday","Thrusday"
                ,"Friday","Saturday"
            };

        public IEnumerator GetEnumerator()
        {
            for (int i = 0; i < days.Length; i++)
            {
                yield return days[i];
            }
        }
    }
    class Program05
    {
        static void Main(string[] args)
        {
            DaysofWeek obj = new DaysofWeek();

            foreach (string day in obj)
            {
                Console.WriteLine(day);
            }
           
        }
    }
}
