﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_GenericDemo
{
    class Item
    {
        public string Name { get; set; }
    }

    class ItemCollection :IEnumerable
    {
        List<Item> items = new List<Item>();

        public void Add(string name)
        {
            items.Add(new Item { Name = name });
        }

        public IEnumerator GetEnumerator()
        {
            foreach (Item item in items)
            {
                yield return item.Name;
            }
        }
    }
    
    class Program06
    {
        static void Main(string[] args)
        {
            ItemCollection obj = new ItemCollection();

            obj.Add("Aniket");
            obj.Add("Suresh");
            obj.Add("Anil");
            obj.Add("Nilesh");

            foreach (string name in obj)
            {
                Console.WriteLine(name);
            }
        }
    }
}
