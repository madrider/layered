﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_GenericDemo
{
    class Program07
    {
        //Using Collection Intializer
        List<Product> plist = new List<Product>()
        {
            new Product {ID=101,Name="Pen",Price=99 },
            new Product {ID=102,Name="Pencil",Price=20 }
        };
    }
}
