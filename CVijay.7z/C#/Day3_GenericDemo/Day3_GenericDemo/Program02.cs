﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_GenericDemo
{
    //Generic Method Demo
    class Program02
    {
        static void DisplayArray<T>(params T[] arr) 
            //where T : struct
        {
            foreach (T data in arr)
            {
                Console.Write(data+"\t");
            }
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            int[] num = { 10, 88, 299, 17, 99, 17171 };
            string[] names = { "vijay", "malcolm", "asdin", "suresh", "aniket", "ajay" };

            DisplayArray<int>(num);

            DisplayArray<string>(names);
        }
    }
}
