﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_GenericDemo
{
    class Numbers<T> //Generic Class
    {
        //Generic Properties
        public T Num1 { get; set; }
        public T Num2 { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Numbers<int> obj1 = new Numbers<int>();
            obj1.Num1 = 210;
            obj1.Num2 = 19;

            Numbers<float> obj2 = new Numbers<float>();
            obj2.Num1 = 19.99F;
            obj2.Num2 = 8.99F;
        }
    }
}
