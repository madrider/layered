﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_GenericDemo
{
    class Data<TYPE1, TYPE2>
    {
        public TYPE1 FirstData { get; set; }
        public TYPE2 SecondData { get; set; }
    }

    class Program01
    {
        static void Main(string[] args)
        {
            Data<int, string> data1 = new Data<int, string>()
            {
                FirstData=1001,SecondData="Aniket"
            };

            Data<DateTime, double> data2 = new Data<DateTime, double>()
            {
                FirstData = Convert.ToDateTime("03/03/2017"),
                SecondData = 88988.99
            };

            Console.WriteLine("Employee Information");
            Console.WriteLine("ID ="+data1.FirstData);
            Console.WriteLine("Name = "+data1.SecondData);
            Console.WriteLine("DOJ ="+data2.FirstData);
            Console.WriteLine("Salary ="+data2.SecondData);
        }
    }
}
