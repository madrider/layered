﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_GenericDemo
{
    class Program03
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> obj = 
                new Dictionary<int, string>();

            obj.Add(101, "Aniket");
            obj.Add(102, "Anil");
            obj.Add(103, "Suresh");
            obj.Add(104, "Malcolm");

            ICollection<int> key = obj.Keys;

            foreach (int k in key)
            {
                Console.WriteLine(k+"---->"+obj[k]);
            }
        }
    }
}
