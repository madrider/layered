﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_GenericDemo
{
    class Product
    {
        public int ID { get; set; }
        public string  Name { get; set; }
        public double Price { get; set; }
    }

    class Program04
    {
        static void Main(string[] args)
        {
            List<Product> plist = new List<Product>();
            int noofproducts;
            Console.WriteLine("Enter no of products to add");
            noofproducts = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < noofproducts; i++)
            {
                Product p = new Product();
                Console.WriteLine("Enter Product ID,Name,Price");
                p.ID = Convert.ToInt32(Console.ReadLine());
                p.Name = Console.ReadLine();
                p.Price = Convert.ToDouble(Console.ReadLine());

                plist.Add(p);
            }

            Console.WriteLine("Displaying Product Information");
            foreach (Product prod in plist)
            {
                Console.WriteLine("{0} {1} {2}",
                    prod.ID,prod.Name,prod.Price);
            }
        }
    }
}
