﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_MyLibrayDemo
{
    /// <summary>
    /// This is a Sample Calculator Class
    /// </summary>
    public class Calculator
    {
        /// <summary>
        /// Adds two numbers
        /// </summary>
        /// <param name="x">First Parameter</param>
        /// <param name="y">Second Parameter</param>
        /// <returns>sum of x and y</returns>
        public static int Sum(int x, int y)
        {
            return (x + y);
        }

        public static void Sqaure(int x)
        {
            Console.WriteLine("Square = "+(x*x));
        }
    }
}
