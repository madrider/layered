﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Day2_MyLibrayDemo;

namespace Day2_MyLibraryTestClient
{

    class Program
    {
        static void Main(string[] args)
        {
            int result = Calculator.Sum(10, 30);
            Console.WriteLine("Sum = "+result);

            Calculator.Sqaure(10);
         }
    }
}
