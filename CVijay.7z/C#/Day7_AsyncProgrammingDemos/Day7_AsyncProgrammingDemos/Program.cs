﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Day7_AsyncProgrammingDemos
{
    class Program
    {
        public static void RunMillionIterations()
        {
            string x = "";

            for (int i = 0; i < 1000000; i++)
            {
                x += i;
            }
        }

        static void Main(string[] args)
        {
            //Thread thread = 
            //    new Thread(RunMillionIterations);
            //thread.Start();
            Parallel.For(0, 1000000, 
                x => RunMillionIterations());
        }
    }
}
