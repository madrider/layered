﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Day7_AsyncProgrammingDemos
{
    class Program03
    {
        static bool IsDivisibleByFive(int i)
        {
            Thread.SpinWait(2000000);

            return i % 5 == 0;
        }

        static void Main(string[] args)
        {
            IEnumerable<int> numberList = Enumerable.Range(1, 10000);

            //PLinq
            IEnumerable<int> resultlist = from n in numberList.AsParallel()
                                          where IsDivisibleByFive(n)
                                          select n;

            Stopwatch sw = Stopwatch.StartNew();
            IList<int> resultdata = resultlist.ToList();

            Console.WriteLine("Total Count = "+resultdata.Count);

            Console.WriteLine("Time Elapsed = "+sw.ElapsedMilliseconds/1000);
            
        }
    }
}
