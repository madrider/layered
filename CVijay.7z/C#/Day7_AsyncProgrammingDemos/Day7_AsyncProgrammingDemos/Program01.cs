﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Day7_AsyncProgrammingDemos
{
    class Program01
    {
        static Random random=new Random();

        static int BookCar()
        {
            Console.WriteLine("Car Booking Started....");
            Thread.Sleep(8000);
            Console.WriteLine("Car Booking Completed....");

            return random.Next();
        }

        static int BookTrain()
        {
            Console.WriteLine("Train Booking Started....");
            Thread.Sleep(6000);
            Console.WriteLine("Train Booking Completed....");

            return random.Next();
        }

        static int BookFlight()
        {
            Console.WriteLine("Flight Booking Started....");
            Thread.Sleep(5000);
            Console.WriteLine("Flight Booking Completed....");

            return random.Next();
        }

        static void Main(string[] args)
        {
            Stopwatch sw = Stopwatch.StartNew();

            //Calling Methods
            //int carID = BookCar();
            //int trainID = BookTrain();
            //int flightID = BookFlight();

            //Using Task Class
            Task<int> carID = 
                Task<int>.Factory.StartNew(BookCar);
            Task<int> trainID = 
                Task<int>.Factory.StartNew(BookTrain);
            Task<int> flightID = 
                Task<int>.Factory.StartNew(BookFlight);

            Task task1 = Task.Factory.StartNew(()=>
            {
                Console.WriteLine("Created a Task using Lambda Expression");
                Thread.Sleep(3000);
                Console.WriteLine("Have a Nice Day....");
            });
            Console.WriteLine("Car ID = "+carID.Result);
            Console.WriteLine("Train ID = " + trainID.Result);
            Console.WriteLine("Flight ID = " + flightID.Result);

            Console.WriteLine("\nTotal Time Elapsed = "+sw.ElapsedMilliseconds/1000);

        }
    }
}
