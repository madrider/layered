﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7_AsyncProgrammingDemos
{
    class Program02
    {
        static void SortList(List<int> list)
        {
            var data = from num in list
                       orderby num ascending
                       select num;

            foreach (var d in data)
            {
                Console.Write(d + "\t");
            }

            Console.WriteLine();
        }

        static void SortListParallel(List<int> list)
        {
            var data = from num in list.AsParallel()
                       orderby num ascending
                       select num;

            foreach (var d in data)
            {
                Console.Write(d + "\t");
            }

            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            List<int> numbers = new List<int> { 10,9,66,1,101,-99,6};

            Console.WriteLine("Sorting List Normally..");
            SortList(numbers);

            Console.WriteLine("Sorting List Parallely..");
            SortListParallel(numbers);
        }
    }
}
