﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_SampleConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to C#");

            Console.WriteLine("Enter name");
            string name = Console.ReadLine();

            Console.WriteLine(name+" Have a Nice Day...");

            //Console.ReadLine();
        }
    }
}
