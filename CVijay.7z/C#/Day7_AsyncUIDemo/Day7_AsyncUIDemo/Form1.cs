﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day7_AsyncUIDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //private async Task<string> LoongImpotantMethodAsync(string name)
        //{
        //    return await Task<string>.Factory.StartNew(() => SomeLognMethod(name));
        //}

        private async Task<string> LongImportantMethodAsync(string name)
        {
            return await Task<string>.Factory.
                StartNew(() => SomeLognMethod(name));
        }
        private string SomeLognMethod(string name)
        {
            Thread.Sleep(20000);

            return name + ", Welcome to Capgemini";
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            //string result = SomeLognMethod("Sanket");

            string result = await LongImportantMethodAsync("Vijay");

            textBox1.Text = result;            
        }
    }
}
