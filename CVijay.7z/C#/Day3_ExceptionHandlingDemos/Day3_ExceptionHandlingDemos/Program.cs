﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_ExceptionHandlingDemos
{
    //Simple Try Catch Demo
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                Console.WriteLine("Program Started");
                int z = 0;

                Console.WriteLine("Enter a Number");

                int x = Convert.ToInt32(Console.ReadLine());

                int result = x / z;

                Console.WriteLine("Result = " + result);

                Console.WriteLine("Program is exiting");
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception Caught");
                //Console.WriteLine(e);
                Console.WriteLine("Error Message =" + e.Message);
                Console.WriteLine("Source = " + e.Source);
                Console.WriteLine("Target Site = " + e.TargetSite);
            }
            finally
            {
                Console.WriteLine("Hello,I am in Finally Block");
            }
        }
    }
}
