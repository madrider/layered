﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_ExceptionHandlingDemos
{
    //Multiple Catch Example
    class Program01
    {
        static void Main(string[] args)
        {
            try
            {
                double[] data = new
                    double[] { 10.99, 99.66, 88.99, 991, 65.11, 9.88 };

                int[] intdata = new int[data.Length];

                //data.CopyTo(intdata, 0);//throw ArrayTypeMismatchException

                //data[9] = 88.77;

                throw new NullReferenceException();
            }            
            catch (ArrayTypeMismatchException ex)
            {
                Console.WriteLine("Array Type Mismatch");
                Console.WriteLine(ex.Message);
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine("Index out of Range");
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("General Catch Block");
                Console.WriteLine(e.Message);
            }
        }
    }
}
