﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_ExceptionHandlingDemos
{
    class Product
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
    }

    class Program03
    {
        private static bool Validate(Product p)
        {
            bool validProduct = true;
            StringBuilder sb = new StringBuilder();

            if (p.ID <= 0)
            {
                validProduct = false;
                sb.Append("\nProduct Id Cannot be Negative or Zero");
            }

            if (p.Name == string.Empty)
            {
                validProduct = false;
                sb.Append("\nProduct Name cannot be blank");
            }

            if (p.Price <= 0)
            {
                validProduct = false;
                sb.Append("\nProduct Price Cannot be Negative or Zero");
            }

            if (validProduct == false)
                throw new MyCustomException(sb.ToString());

            return validProduct;
        }

        public static void DisplayProduct(Product p)
        {
            try
            {
                if (Validate(p))
                {
                    Console.WriteLine("Product Information");
                    Console.WriteLine("Id = " + p.ID);
                    Console.WriteLine("Name = " + p.Name);
                    Console.WriteLine("Price = " + p.Price);
                }
            }
            catch (MyCustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        static void Main(string[] args)
        {
            try
            {
                Product prod = new Product();

                Console.WriteLine("Enter Product ID,Name and Price");
                prod.ID = Convert.ToInt32(Console.ReadLine());
                prod.Name = Console.ReadLine();
                prod.Price = Convert.ToDouble(Console.ReadLine());

                DisplayProduct(prod);
            }
            catch (MyCustomException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
