﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_ExceptionHandlingDemos
{   
    //Using Custom Exception Class
    class Program02
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter a Number");
                int num = Convert.ToInt32(Console.ReadLine());

                if (num > 0 && num % 4 == 0)
                {
                    Console.WriteLine("Valid Number");
                }
                else
                {
                    throw new 
                        MyCustomException("Number is Negative and Not divisble by 4");
                }
            }
            catch (MyCustomException ex)
            {
                Console.WriteLine("Exception Caught");
                Console.WriteLine("Error Message :"+ex.Message);
            }
        }
    }
}
