﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    class Base
    {
        public Base()
        {
            Console.WriteLine("Base Class Constructor called...");
        }
    }

    class Derived : Base
    {
        public Derived()
        {
            Console.WriteLine("Derived Class Constructor called...");
        }

        public void SampleMethod()
        {
            Console.WriteLine("SampleMethod from Derived class called");
        }
    }

    class Program07
    {
        static void Main(string[] args)
        {
            Derived obj = new Derived();

            obj.SampleMethod();
        }
    }
}
