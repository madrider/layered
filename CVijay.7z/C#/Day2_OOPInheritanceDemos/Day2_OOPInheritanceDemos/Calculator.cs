﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    class Calculator : IMaths
    {
        public void Subtract(int x, int y)
        {
            Console.WriteLine("Difference = "+(x-y)); 
        }

        public void Sum(int x, int y)
        {
            Console.WriteLine("Sum = "+(x+y));
        }

        static void Main(string[] args)
        {
            Calculator obj = new Calculator();

            obj.Sum(10, 88);
            obj.Subtract(88, 98);
        }
    }


}
