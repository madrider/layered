﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    //Hiding Base Class Member using Method Hiding
    class A
    {
        public void Show()
        {
            Console.WriteLine("Show() of Base Class");
        }
    }

    class B : A
    {
        public new void Show()
        {
            base.Show();
            Console.WriteLine("Show() of Derived class");
        }
    }
    class Program05
    {
        static void Main(string[] args)
        {
            B objDerived = new B();
            objDerived.Show();
        }
    }
}
