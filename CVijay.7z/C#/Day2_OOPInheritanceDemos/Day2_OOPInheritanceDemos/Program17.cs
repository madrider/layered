﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    //Anonymous Type Demo
    class Program17
    {
        static void Main(string[] args)
        {
            var person = new { Name = "Vijay", Age = 27 };
            var points = new { X = 10, Y = 5 };

            Console.WriteLine("Person Information");
            Console.WriteLine(person.Name);
            Console.WriteLine(person.Age);
        }
    }

    partial class Customer
    {
        public void Display()
        {
            Console.WriteLine("Customer Information");
            Console.WriteLine(ID);
            Console.WriteLine(Name);
            Console.WriteLine(Location);
        }
    }
}
