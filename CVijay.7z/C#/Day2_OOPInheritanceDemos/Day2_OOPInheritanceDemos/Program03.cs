﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    class Rect
    {
        protected int length, bredth;

        public void SetDimension(int len, int bred)
        {
            this.length = len;
            this.bredth = bred;
        }
    }

    class Area : Rect
    {
        public void GetArea()
        {
            Console.WriteLine("Area of Rectangle = "+
                (length*bredth));
        }
    }
    class Program03
    {
        static void Main(string[] args)
        {
            Area obj = new Area();
            obj.SetDimension(10, 8);
            obj.GetArea();
        }
    }
}
