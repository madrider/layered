﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    //Multilevel Inheritance
    class Animal
    {
        public void Eat()
        {
            Console.WriteLine("Every Animal Eats to Survive");
        }
    }

    class Terrestial : Animal
    {
        public void Walk()
        {
            Console.WriteLine("Terrestial Animal walk on land");
        }
    }

    class Dog : Terrestial
    {
        public void Noise()
        {
            Console.WriteLine("Dog Barks...");
        }
    }
    class Program04
    {
        static void Main(string[] args)
        {
            Dog obj = new Dog();

            obj.Eat();
            obj.Walk();
            obj.Noise();
        }
    }
}
