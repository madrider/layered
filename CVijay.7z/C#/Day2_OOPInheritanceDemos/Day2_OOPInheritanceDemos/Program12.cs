﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    interface IAnimals
    {
        void Drink();
    }

    interface ICarnivorous
    {
        void Eat();
    }

    interface IReptile : IAnimals, ICarnivorous
    {
        void Habitat();
    }

    class Crocodile : IReptile
    {
        public void Drink()
        {
            throw new NotImplementedException();
        }

        public void Eat()
        {
            throw new NotImplementedException();
        }

        public void Habitat()
        {
            throw new NotImplementedException();
        }
    }
    class Program12
    {
    }
}
