﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    partial class Customer
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string  Location { get; set; }

        public Customer(int id, string name, string location)
        {
            this.ID = id;
            this.Name = name;
            this.Location = location;
        }
    }

    class Program18
    {
        static void Main(string[] args)
        {
            Customer obj = new Customer(1001, "Vijay", "Mumbai");
            obj.Display();
        }
    }
}
