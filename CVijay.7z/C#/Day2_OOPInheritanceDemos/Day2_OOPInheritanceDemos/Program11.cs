﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    abstract class Animals
    {
        public void Activity()
        {
            Console.WriteLine("Every Animal does some activity..");
        }

        public virtual void Eat()
        {
            Console.WriteLine("Every Animal eats to survive");
        }

        public abstract void Sound();//abstract method
    }

    class Lion:Animals
    {
        public override void Sound()
        {
            Console.WriteLine("Lion Roars.....");
        }

        public override void Eat()
        {
            Console.WriteLine("Lion eats flesh....");
        }
    }
    class Program11
    {
        static void Main(string[] args)
        {
            //Animals obj1 = new Animals();
            Lion obj = new Lion();
            obj.Activity();
            obj.Eat();
            obj.Sound();
        }
    }
}
