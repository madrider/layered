﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    
    class Cat
    {
        public void DoSomething()
        {
            Console.WriteLine("Cat are lazy");
        }

        public virtual void Eat()
        {
            Console.WriteLine("Cats loves to drink milk");
        }
    }

    class Tom : Cat
    {
        public override void Eat()
        {
            Console.WriteLine("Tom tries to eat jerry");
        }
    }
    class Program09
    {
        static void Main(string[] args)
        {
            Tom obj = new Tom();
            obj.DoSomething();
            obj.Eat();        
        }
    }
}
