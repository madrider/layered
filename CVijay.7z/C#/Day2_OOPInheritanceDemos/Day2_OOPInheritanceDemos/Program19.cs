﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    class PhoneBook
    {
        public string Name { get; set; }
        public long ContactNo { get; set; }
        public string Email { get; set; }

        public void DisplayInfo()
        {
            Console.WriteLine("Phone Information");
            Console.WriteLine(Name);
            Console.WriteLine(ContactNo);
            Console.WriteLine(Email);
        }

        public override string ToString()
        {
            return Name + "," + ContactNo + "," + Email;
        }
    }
    class Program19
    {
        static void Main(string[] args)
        {
            PhoneBook phone = new PhoneBook();

            Console.WriteLine("Enter Name");
            phone.Name = Console.ReadLine();

            Console.WriteLine("Enter Contact No");
            phone.ContactNo = Convert.ToInt64(Console.ReadLine());

            Console.WriteLine("Enter Email Address");
            phone.Email = Console.ReadLine();

            phone.DisplayInfo();

            Console.WriteLine(phone.ToString());
        }
    }
}
