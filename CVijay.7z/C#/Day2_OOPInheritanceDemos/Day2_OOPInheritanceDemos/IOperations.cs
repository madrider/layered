﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    interface IOperations
    {
        void Sum(int x, int y);

        void Product(int x, int y);

        string Message { get; set; }
    }
}
