﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    interface IMaths
    {
        void Sum(int x, int y);
        void Subtract(int x, int y);
    }
}
