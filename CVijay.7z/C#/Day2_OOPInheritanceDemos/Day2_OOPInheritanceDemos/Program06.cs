﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    //Base class Reference Demo
    class BaseClass
    {
        public void Show()
        {
            Console.WriteLine("Inside Base Class");
        }
    }

    class DerivedClass : BaseClass
    {
        public void Display()
        {
            Console.WriteLine("Inside Derived Class");
        }
    }

    class Program06
    {
        static void Main(string[] args)
        {
            DerivedClass obj = new DerivedClass();
            obj.Show();
            obj.Display();

            BaseClass objBase = new DerivedClass();
            objBase.Show();
            //objBase.Display();
        }
    }
}
