﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    //Runtime Polymorphism
    class ShapeClass
    {
        public virtual void Draw()
        {
            Console.WriteLine("Draw () from Shape Class");
        }
    }

    class Circle : ShapeClass
    {
        public override void Draw()
        {
            Console.WriteLine("Draw () from Circle Class");
        }
    }

    class Square : ShapeClass
    {
        public override void Draw()
        {
            Console.WriteLine("Draw () from Square Class");
        }
    }
    class Program10
    {
        static void Main(string[] args)
        {
            ShapeClass objShape;

            objShape = new ShapeClass();
            objShape.Draw();//Draw from base class

            objShape = new Circle();
            objShape.Draw();

            objShape = new Square();
            objShape.Draw();
        }
    }
}
