﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    struct Point
    {
        public int X { get; set; }
        public int Y { get; set; }
    }

    class Program15
    {
        static void Main(string[] args)
        {
            Point p = new Point { X = 10, Y = 55 };
            Console.WriteLine("X= {0} Y ={1}",p.X,p.Y);
        }
    }
}
