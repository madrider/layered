﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    class Super//Base Class
    {
        int x;

        public Super(int x)
        {
            this.x = x;
        }

        public void DisplayX()
        {
            Console.WriteLine("X = "+x);
        }
    }

    //Derived class
    class Sub : Super 
    {
        int y;

        public Sub():base(6)
        {
            y = 7;
        }

        public Sub(int x, int y) : base(x)
        {
            this.y = y;
        }
        public void DisplayY()
        {
            Console.WriteLine("Y = "+y);
        }
    }

    class Program08
    {
        static void Main(string[] args)
        {
            Sub obj = new Sub();
            obj.DisplayX();
            obj.DisplayY();

            Sub obj1 = new Sub(10, 88);
            obj1.DisplayX();
            obj1.DisplayY();

        }
    }
}
