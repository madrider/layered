﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    class Employee//Base Class
    {
        int empid;
        string empname;

        public void SetEmployee(int id, string name)
        {
            empid = id;
            empname = name;
        }

        protected void GetEmployee()
        {
            Console.WriteLine("Id = " + empid);
            Console.WriteLine("Name = " + empname);
        }
    }

    class Manager : Employee//Derived Class
    {
        string deptname;
        int nofoemps;

        public void SetManager(string dname, int count)
        {
            deptname = dname;
            nofoemps = count;
        }

        public void GetManager()
        {
            GetEmployee();
            Console.WriteLine("Department name = " + deptname);
            Console.WriteLine("No of Employees = " + nofoemps);
        }
    }

    class Program02
    {
        static void Main(string[] args)
        {
            Manager mgr = new Manager();
            mgr.SetEmployee(1256, "Suresh");
            mgr.SetManager("Accounts", 50);
           
            mgr.GetManager();
        }
    }
}
