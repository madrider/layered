﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    class Electronics { }

    sealed class TV : Electronics { }

    //class LEDTV : TV { }

    class Program13
    {
    }
}
