﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    class Calculators : IOperations
    {
        string _message;
        public string Message
        {
            get
            {
                return _message;
            }

            set
            {
                _message = value;
            }
        }

        public void Product(int x, int y)
        {
            Console.WriteLine("Product = "+(x*y));
        }

        public void Sum(int x, int y)
        {
            Console.WriteLine("Sum = "+(x+y));
        }
    }
    class Program20 
    {
        static void Main(string[] args)
        {
            Calculators obj = new Calculators();
            obj.Message = "Interface Demo";
            Console.WriteLine(obj.Message);

            obj.Sum(10, 8);
            obj.Product(8, 9);
        }
    }
}
