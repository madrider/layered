﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    static class MyExtension
    {
        public static bool IsNumeric(this string s)
        {
            float result;
            return float.TryParse(s, out result);
        }
    }
    class Program16
    {
        static void Main(string[] args)
        {
            string data = "1234";

            if (data.IsNumeric())
            {
                Console.WriteLine("Valid Data");
            }
            else
            {
                Console.WriteLine("Invalid Data");
            }
        }
    }
}
