﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    struct Product
    {
        int id;
        string name;
        double price;

        //public Product() { }

        public Product(int id, string name, double price)
        {
            this.id = id;
            this.name = name;
            this.price = price;
        }

        public void Display()
        {
            Console.WriteLine("Product Information");
            Console.WriteLine("{0} {1} {2}",id,name,price);
        }
    }
    class Program14
    {
        static void Main(string[] args)
        {
            Product p = new Product(101, "Mouse", 778.99);
            p.Display();
        }
    }
}
