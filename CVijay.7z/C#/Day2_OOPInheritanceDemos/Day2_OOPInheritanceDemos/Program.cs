﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPInheritanceDemos
{
    //Single Inheritance
    class Vehicle//Base Class
    {
        public void ShowRegistration()
        {
            Console.WriteLine("Method from Base Class");
        }
    }

    class Car : Vehicle//Derived Class
    {
        public void ShowManufacturer()
        {
            Console.WriteLine("Method from Derived Class");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Car objCar = new Car();

            objCar.ShowRegistration();
            objCar.ShowManufacturer();
        }
    }
}
