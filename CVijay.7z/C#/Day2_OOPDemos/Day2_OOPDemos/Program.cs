﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPDemos
{
    class Rectangle
    {
        //Data Member
        private int length, bredth;

        //Member Functions
        public void SetDimensions(int len, int bre)
        {
            length = len;
            bredth = bre;
        }

        public void Display()
        {
            Console.WriteLine("Length = "+length);
            Console.WriteLine("Bredth = "+bredth);
            Console.WriteLine("Area = "+(length*bredth));
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle obj = new Rectangle();

            obj.SetDimensions(10, 20);
            obj.Display();
        }
    }
}
