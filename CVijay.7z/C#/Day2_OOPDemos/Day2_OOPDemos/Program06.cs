﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPDemos
{
    class Program06
    {
        static int Area(int len, int bre)
        {
            return (len * bre);
        }

        static float Area(float s)
        {
            return (s * s);
        }

        static double Area(double rad)
        {
            return (Math.PI * rad * rad);
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Area of Rectangle = " + Area(10, 7));
            Console.WriteLine("Area of Circle = " + Area(5.789));
            Console.WriteLine("Area of Cube = " + Area(2.5F));
        }
    }
}
