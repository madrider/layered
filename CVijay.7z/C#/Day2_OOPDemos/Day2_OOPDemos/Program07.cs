﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPDemos
{
    class Product
    {
        int code;
        string name, category;
        float price;

        public void SetProduct(int id, string n, string c, float pri)
        {
            code = id;
            name = n;
            category = c;
            price = pri;
        }

        public void SetProduct(int id, string n, float pri)
        {
            code = id;
            name = n;
            price = pri;

            category = "General";
        }

        public void SetProduct(int id, string n, string cat)
        {
            code = id;
            name = n;

            price = 10.50F;

            category = cat;
        }

        public void GetProduct()
        {
            Console.WriteLine("\nProduct Information\n");
            Console.WriteLine("Code = " + code);
            Console.WriteLine("Name = " + name);
            Console.WriteLine("Price = " + price);
            Console.WriteLine("Category = " + category);
        }
    }
    class Program07
    {
        static void Main(string[] args)
        {
            Product p1 = new Product();
            p1.SetProduct(1001, "TV", "Electronics", 1999.88F);
            p1.GetProduct();

            Product p2 = new Product();
            p2.SetProduct(1099, "Pen", 9.99F);
            p2.GetProduct();

            Product p3 = new Product();
            p3.SetProduct(2199, "Mop", "Grocery");
            p3.GetProduct();
        }
    }
}
