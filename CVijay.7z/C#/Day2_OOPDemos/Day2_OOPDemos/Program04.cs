﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPDemos
{
    //Named and Optional Argument Demo
    class Program04
    {
        static void CalculateInterest(int pri, int no, float rate=1.5F)
        {
            float si = (pri * no * rate) / 100;
            Console.WriteLine("Simple Interest = "+si);
        }

        static void Main(string[] args)
        {
            //optional arguments
            CalculateInterest(1000, 8);

            //named arguments
            CalculateInterest(rate: 2.7F, pri: 7000, no: 2);
        }
    }
}
