﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPDemos
{
    class Program03
    {
        static void DispArray(int[] arr)
        {
            Console.WriteLine("Content of Array");
            foreach (int num in arr)
            {
                Console.Write(num + "\t");
            }
            Console.WriteLine();
        }

        public static void DisplayArray(params int[] arr)
        {
            Console.WriteLine("Content of Array");
            foreach (int num in arr)
            {
                Console.Write(num + "\t");
            }
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            int[] numbers = { 10, 7, 988, 29, 9, 4, 66, 99, 33 };

            DispArray(numbers);

            DisplayArray(10, 5, 76, 696);

            DisplayArray(numbers);
        }
    }
}
