﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPDemos
{
    class Program05
    {
        //Method Overloading Example
        static void Add(int x, int y)
        {
            Console.WriteLine("Sum = " + (x + y));
        }

        static void Add(int x, int y, int z)
        {
            Console.WriteLine("Sum = " + (x + y + z));
        }

        static void Add(double x, double y)
        {
            Console.WriteLine("Sum = " + (x + y));
        }

        static void Main(string[] args)
        {
            Add(10, 8);
            Add(5, 6, 7);
            Add(199.88, 889.88);

        }
    }
}
