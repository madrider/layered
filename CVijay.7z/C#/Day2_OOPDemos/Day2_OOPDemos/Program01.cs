﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPDemos
{
    class Program01
    {
        //Call By Value and Reference Demo
        void ChangeNumberbyVal(int x)
        {
            x = x + 10;
        }

        void ChangeNumberbyReference(ref int x)
        {
            x = x + 10;
        }

        static void Main(string[] args)
        {
            int num = 100;

            Program01 obj = new Program01();

            Console.WriteLine("Value before change ="+num);

            obj.ChangeNumberbyVal(num);

            Console.WriteLine("Value after change = "+num);

            obj.ChangeNumberbyReference(ref num);

            Console.WriteLine("Value after change = " + num);
        }
    }
}
