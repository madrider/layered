﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OOPDemos
{
    //Output Parameters Demo
    class Sample
    {
        public static int Operation(int x, int y,
            out int result1,out int result2)
        {
            result1 = x - y;
            result2 = x * y;

            return x + y;
        }
    }
    class Program02
    {
        static void Main(string[] args)
        {
            int res1, res2;
            int x=9, y = 10;

            int sum =
                Sample.Operation(x,y, out res1, out res2);

            Console.WriteLine("Sum = "+sum);
            Console.WriteLine("Difference = "+res1);
            Console.WriteLine("Product ="+res2);
        }
    }
}
