﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_ReflectionDemo
{
    class Calculator
    {
        [Obsolete("This method is no longer support use AddNumbers instead",true)]
        public int Add(int x, int y)
        {
            return x + y;
        }

        public int AddNumbers(params int[] arr)
        {
            int sum = 0;
            foreach (int x in arr)
            {
                sum += x;
            }

            return sum;
        }
    }
    class Program04
    {
        static void Main(string[] args)
        {
            Calculator obj = new Calculator();
            // Console.WriteLine(obj.Add(10,9));
            Console.WriteLine(obj.AddNumbers(10,9,188));
        }
    }
}
