﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Day5_ReflectionDemo
{
    //Creating Custom Attributes
   // [AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct)]
   [AttributeUsage(AttributeTargets.All)]
    class AuthorAttribute : Attribute
    {
        public string _name, _version;

        public AuthorAttribute()
        { }

        public AuthorAttribute(string name, string version)
        {
            this._name = name;
            this._version = version;
        }
    }

    [Author("Vijay","1.1")]
    class Person
    {
        public int ID { get; set; }
        public string Name { get; set; }
        //[Author("Suresh","1.0")]
        public string Address { get; set; }
    } 

    class Program05
    {
        static void Main(string[] args)
        {
            //checking attribute is applied or not
            AuthorAttribute attr =
              (AuthorAttribute)Attribute.
                GetCustomAttribute(typeof(Person), 
                typeof(AuthorAttribute));

            if (attr == null)
            {
                Console.WriteLine("Custom Attribute not Applied");
            }
            else
            {
                Console.WriteLine("Custom Attribute Applied = "+attr._name);
            }

            //Displaying all Custom Attributes Applied
            Assembly assembly = Assembly.GetExecutingAssembly();

            Type type = 
                assembly.GetType("Day5_ReflectionDemo.Person");

            Attribute[] attributes = 
                Attribute.GetCustomAttributes(type);

            foreach (Attribute att in attributes)
            {
                Console.WriteLine(att);
            }

        }
    }
}
