﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Day5_ReflectionDemo
{
    class Calculations
    {
        private static int AddTwoNumbers(int x, int y)
        {
            return x + y;
        }
    }

    class Program03
    {
        static void Main(string[] args)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();

            Type type = assembly.
                GetType("Day5_ReflectionDemo.Calculations");

            MethodInfo method = type.GetMethod("AddTwoNumbers",
                BindingFlags.NonPublic | BindingFlags.Static);

            object[] parameters = { 10, 99 };

            int result = (int)method.Invoke(type, parameters);

            Console.WriteLine("Result = "+result);
        }
    }
}
