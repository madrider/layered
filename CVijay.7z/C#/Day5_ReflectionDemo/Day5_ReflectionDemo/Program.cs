﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Data;

namespace Day5_ReflectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Assembly assembly =
            //    Assembly.LoadFrom(@"C:\Windows\Microsoft.NET\Framework\v2.0.50727\System.Drawing.dll");

            Assembly assembly =
                Assembly.LoadFrom(@"D:\Training Content\C# Chennai\BookManagementSystem\BMS.DAL\bin\Debug\BMS.DAL.dll");

            Type[] types = assembly.GetTypes();

            foreach (Type type in types)
            {
                Console.WriteLine(type.Name+"--"+type.FullName+"--"+type.BaseType);
            }
        }
    }
}
