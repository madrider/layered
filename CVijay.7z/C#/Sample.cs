//First C# Program
using System;

class Sample
{
	public static void Main(string [] args)
	{
	Console.WriteLine("Welcome to C#");

	string name = args[0];
		
	Console.WriteLine(name +",Have a Nice Day.....");

	Console.Read();
	}
}