﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_DataTypeDemos
{
    class Program01
    {
        static void Main(string[] args)
        {
            //Product Information
            Console.WriteLine("Enter Product ID");
            int prodid =Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enetr Product Name");
            string name = Console.ReadLine();

            Console.WriteLine("Enter Product Price");
            float price = Convert.ToSingle(Console.ReadLine());

            //Displaying Product Information
            Console.WriteLine("Product Information");
            Console.WriteLine("{0} {1} {2:C}",
                prodid,name,price);

        }
    }
}
