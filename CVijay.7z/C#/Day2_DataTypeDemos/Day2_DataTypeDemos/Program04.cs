﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_DataTypeDemos
{
    class Program04
    {
        //Implicitly Type Local Variable Demo
        static void Main(string[] args)
        {
            var id = 101;
            var name = "Vijay";
            var status = false;

            Console.WriteLine("{0} {1} {2}",
                id,name,status);
                
        }
    }
}
