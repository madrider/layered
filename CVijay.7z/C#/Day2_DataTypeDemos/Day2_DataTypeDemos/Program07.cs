﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_DataTypeDemos
{
    class Program07
    {
        static void Main(string[] args)
        {
            string[,] studmarks = new string[,]
               {
                    {"101","Anil" },
                    {"102","Suresh" },
                    {"103","Aniket" }
               };

            for (int i=0; i < studmarks.GetLength(0); i++)
            {
                for (int j = 0; j < studmarks.GetLength(1); j++)
                {
                    Console.WriteLine(studmarks[i, j]);
                }
                Console.WriteLine();
            }
        }
    }
}
