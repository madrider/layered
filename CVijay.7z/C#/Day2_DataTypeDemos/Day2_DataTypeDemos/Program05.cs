﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_DataTypeDemos
{
    class Program05
    {
        //Single Dimension Demo
        static void Main(string[] args)
        {
            //Declaring an array
            string[] cities = new string[5];

            Console.WriteLine("Enter 5 City names");
            for (int i = 0; i < cities.Length; i++)
            {
                cities[i] = Console.ReadLine();
            }

            Console.WriteLine("\nContent of the array");
            foreach (string city in cities)
            {
                Console.WriteLine(city);
            }
        }
    }
}
