﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_DataTypeDemos
{
    class Program06
    {
        static void Main(string[] args)
        {
            int[] num = { 10, 7, 5, 119, 828, 99, -18, 0 };

            Console.WriteLine("Length ="+num.Length);

            Array.Sort(num);

            foreach (int n in num)
            {
                Console.Write(n + "\t");
            }
            Console.WriteLine();
            Array.Reverse(num);
            foreach (int n in num)
            {
                Console.Write(n + "\t");
            }
            Console.WriteLine();
        }
    }
}
