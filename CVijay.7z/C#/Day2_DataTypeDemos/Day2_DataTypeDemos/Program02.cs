﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_DataTypeDemos
{
    class Program02
    {
        //Boxing and Unboxing Demo
        static void Main(string[] args)
        {
            int x = 1000;

            object o = x;//Boxing;

            Console.WriteLine("X = "+x);
            Console.WriteLine("o = "+o);

            int y = (int)o;//UnBoxing

            Console.WriteLine("Y = "+y);
        }
    }
}
