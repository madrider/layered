﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_DataTypeDemos
{
    class Program
    {
        static void Main(string[] args)
        {
            //Data Type Demo
            //Student Information
            byte rollno = 101;
            string name = "Vijay";
            char gender = 'M';
            float marks = 76.99F;

            //Displaying Student Information
            Console.WriteLine("Student Information");
            Console.WriteLine("Roll No ="+rollno);
            Console.WriteLine("Name = "+name);
            Console.WriteLine("Gender = "+gender);
            Console.WriteLine("Marks = "+marks);
        }
    }
}
