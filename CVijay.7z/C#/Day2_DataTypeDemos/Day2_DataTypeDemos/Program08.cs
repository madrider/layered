﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_DataTypeDemos
{
    class Program08
    {
        //Jagged Array Demo
        static void Main(string[] args)
        {
            string[][] companies = new string[3][];

            companies[0] = new string[] { "Microsoft", "IBM", "Apple" };
            companies[1] = new string[] { "HP","Cannon","Epson","Acer"};
            companies[2] = new string[] { "Xbox", "PlayStation" };

            for (int i = 0; i < companies.GetLength(0); i++)
            {
                for (int j = 0; j < companies[i].GetLength(0); j++)
                {
                    Console.Write(companies[i][j]+",");
                }
                Console.WriteLine();
            }
            
        }
    }
}
