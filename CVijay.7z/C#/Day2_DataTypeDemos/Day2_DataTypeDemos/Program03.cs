﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_DataTypeDemos
{
    //Nullable Types Demo
    class Program03
    {
        static void Main(string[] args)
        {
            int? num = null;

            Nullable<bool> status = true;

            if (num.HasValue)
            {
                Console.WriteLine(num.Value);
            }
            else
            {
                Console.WriteLine("No Data");
            }

            if (status.HasValue)
            {
                Console.WriteLine(status.Value);
            }
            else
            {
                Console.WriteLine("No Staus Data");
            }
        }
    }
}
