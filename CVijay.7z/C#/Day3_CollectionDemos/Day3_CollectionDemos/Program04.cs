﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_CollectionDemos
{
    class Program04
    {
        static void Main(string[] args)
        {
            Queue objQueue = new Queue();
            objQueue.Enqueue(10);
            objQueue.Enqueue(20);
            objQueue.Enqueue(30);
            objQueue.Enqueue(40);
            objQueue.Enqueue(50);

            Console.WriteLine("No of elements :- " + 
                objQueue.Count);
            Console.WriteLine("Top Element :- " + 
                objQueue.Peek());

            objQueue.Dequeue();

            Console.WriteLine("Top Element After removing one element:- " + objQueue.Peek());
        }
    }
}
