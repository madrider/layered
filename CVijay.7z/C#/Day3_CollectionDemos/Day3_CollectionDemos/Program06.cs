﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_CollectionDemos
{
    class Program06
    {
        static void Main(string[] args)
        {
            Hashtable htable = new Hashtable();

            htable.Add("INR", "Indian Rupees");
            htable.Add("JYP", "Japanese YEN");
            htable.Add("GBP", "Great Britan Pound");
            htable.Add("USD", "US Dollars");

            Console.WriteLine("INR = "+htable["INR"]);

            htable["GBP"] = "British Pound";
            Console.WriteLine("GBP = "+htable["GBP"]);

            if (htable.ContainsKey("USD"))
            {
                htable["USD"] = "United States Dollar";
            }

            if (!htable.ContainsKey("GER"))
            {
                htable.Add("GER", "Euros");
            }

            foreach (object k in htable.Keys)
            {
                Console.WriteLine(k + "--->" + htable[k] + "--->" + k.GetHashCode().ToString());
            }
        }
    }
}
