﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_CollectionDemos
{
    class Book
    {
        public int Code { get; set; }
        public string  Name { get; set; }
        public string Category { get; set; }
    }

    class Program02
    {
        static void Main(string[] args)
        {
            int NooFBooks;
            ArrayList bookList = new ArrayList();
            Console.WriteLine("Enter the no of books to add");
            NooFBooks = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < NooFBooks; i++)
            {
                Console.WriteLine("Enter Book Code,Name and Category for Book "+(i+1));
                Book book = new Book();

                book.Code = Convert.ToInt32(Console.ReadLine());
                book.Name = Console.ReadLine();
                book.Category = Console.ReadLine();

                bookList.Add(book);
            }

            Console.WriteLine(NooFBooks +" Books added successfully to list");
            DisplayBooks(bookList);
        }

        static void DisplayBooks(ArrayList list)
        {
            Console.WriteLine("\nTotal Books = "+list.Count);

            foreach (object obj in list)
            {
                Book book = (Book)obj;
                Console.WriteLine("{0} {1} {2}",
                    book.Code,book.Name,book.Category);
            }
        }
    }
}
