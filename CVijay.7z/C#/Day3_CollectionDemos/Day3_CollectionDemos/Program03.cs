﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_CollectionDemos
{
    class Program03
    {
        static void Main(string[] args)
        {
            Stack objStack = new Stack();

            objStack.Push(10);
            objStack.Push(20);
            objStack.Push(30);
            objStack.Push(40);
            objStack.Push(50);

            Console.WriteLine("No of element :- " + 
                objStack.Count);
            Console.WriteLine("Top Element :- " + 
                objStack.Peek());

            while (objStack.Count > 0)
            {
                Console.WriteLine(objStack.Pop());
            }
        }
    }
}
