﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace Day3_CollectionDemos
{
    class Program05
    {
        static void Main(string[] args)
        {
            Hashtable htable = new Hashtable();

            htable.Add("INR", "India Rupees");
            htable.Add("JYP", "Japanese Yen");
            htable.Add("GBP", "British Pound");
            htable.Add("USD", "US Dollars");

            foreach (DictionaryEntry de in htable)
            {
                Console.WriteLine(de.Key +"--->"+de.Value);
            }

            ICollection keys = htable.Keys;

            foreach (object o in keys)
            {
                string key = (string)o;
                Console.WriteLine("{0}--->{1}", key, htable[key]);
            }
        }
    }
}
