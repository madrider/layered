﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Day3_CollectionDemos
{
    class Program
    {
        //ArrayList Demo
        static void Main(string[] args)
        {
            ArrayList alist = new ArrayList();

            Console.WriteLine("Initial Count = "+alist.Count);
            Console.WriteLine("Initial Capacity = "+alist.Capacity);

            alist.Add(18);
            alist.Add(100);
            alist.Add(12.99);
            alist.Add('A');
            alist.Add("Hello");
            alist.Add(true);

            foreach (object o in alist)
            {
                Console.Write(o + "\t");
            }
            Console.WriteLine();

            Console.WriteLine("\nCount = " + alist.Count);
            Console.WriteLine("Capacity = " + alist.Capacity);

            alist.Remove("Hello");
            alist.RemoveAt(1);

            foreach (object o in alist)
            {
                Console.Write(o + "\t");
            }
            Console.WriteLine();
        }
    }
}
