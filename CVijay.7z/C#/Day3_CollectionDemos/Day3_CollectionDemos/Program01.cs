﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_CollectionDemos
{
    class Program01
    {
        static void Main(string[] args)
        {
            string[] cities = 
                { "Mumbai", "Delhi", "Chennai", "Hyderabad", "Pune", "Bangalore" };

            ArrayList citilist = new ArrayList();

            citilist.AddRange(cities);
            //citilist.Add(cities);

            foreach (string str in citilist)
            {
                Console.WriteLine(str);
            }

            Console.WriteLine(citilist.Count + " " +citilist.Capacity);
        }
    }
}
