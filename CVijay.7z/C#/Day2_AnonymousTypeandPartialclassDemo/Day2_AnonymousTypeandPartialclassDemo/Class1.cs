﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_AnonymousTypeandPartialclassDemo
{
    partial class Customer
    {
        public void Display()
        {
            Console.WriteLine("Customer Information");
            Console.WriteLine("Id = "+ID);
            Console.WriteLine("Name = "+Name);
            Console.WriteLine("City = "+City);
        }
    }
}
