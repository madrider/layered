﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_AnonymousTypeandPartialclassDemo
{
    partial class Customer
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string City { get; set; }

        public Customer(int id, string name, string city)
        {
            this.ID = id;
            this.Name = name;
            this.City = city;
        }
    }
    class Program01
    {
        static void Main(string[] args)
        {
            Customer cust = new Customer(101, "Vijay", "Mumbai");
            cust.Display();
        }
    }
}
