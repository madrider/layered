﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_AnonymousTypeandPartialclassDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Anonymous Types
            var person = new { Name = "Vijay", Age = 28 };
            var points = new { X = 10, Y = 6 };

            Console.WriteLine("Person Details");
            Console.WriteLine("Name = "+person.Name);
            Console.WriteLine("Age = "+person.Age);
        }
    }
}
