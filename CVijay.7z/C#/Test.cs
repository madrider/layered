//Calculator Test Program
using System;
using UtilityLibrary;

class Test
{
	public static void Main(string [] args)
	{
		int result = Calculator.Sum(10,3);
		Console.WriteLine("Sum = "+result);

		Calculator.Square(10);
	}
}