﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_IODemos
{
    class Program07
    {
        static void Main(string[] args)
        {
            string url = @"D:\Sample\Shopping.dat";

            Console.WriteLine(Path.GetExtension(url));
            Console.WriteLine(Path.GetFullPath(url));
            Console.WriteLine(Path.GetPathRoot(url));
            Console.WriteLine(Path.GetFileName(url));
            Console.WriteLine(Path.GetRandomFileName());
            Console.WriteLine(Path.GetTempFileName());
            Console.WriteLine(Path.GetTempPath());
        }
    }
}
