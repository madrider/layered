﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Day5_IODemos
{
    class Program03
    {
        static void Main(string[] args)
        {
            //Using Filestream to Read and Write Data 
            FileStream fstream1 =
                new FileStream(@"D:\Sample\Demo.txt",
                FileMode.Create,
                FileAccess.Write);

            string message = "This is an Exmaple of Filestream using System.IO";

            byte[] writedata = new byte[message.Length];

            writedata = Encoding.ASCII.GetBytes(message);

            fstream1.Write(writedata, 0, writedata.Length);
            fstream1.Close();
            Console.WriteLine("Data Written Successfully...");
        }
    }
}
