﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Day5_IODemos
{
    class Program05
    {
        //StreamWriter and StreamReader Example
        static void Main(string[] args)
        {
            //Writing Data to File
            FileStream fstream1 = new 
                FileStream(@"D:\Sample\TextData.txt",
                FileMode.Create, FileAccess.Write);

            StreamWriter writer = new StreamWriter(fstream1);

            //write data to file
            writer.WriteLine("This is an Example of IO using StreamWriter and Reader");
            writer.WriteLine("Have a Nice day....");

            writer.Close();
            Console.WriteLine("Data Written Successfully....");

            //Reading Data from File
            FileStream fstream2 = 
                new FileStream(@"D:\Sample\TextData.txt",
                FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(fstream2);

            //string data = reader.ReadToEnd();
            //Console.WriteLine(Int64.MaxValue);

            Console.WriteLine("\nData from File...");
            //Console.WriteLine(data);

            int ch = reader.Read();

            while(ch>0)
            {
                Console.Write((char)ch);
                ch = reader.Read();
            }           

            reader.Close();
        }
    }
}
