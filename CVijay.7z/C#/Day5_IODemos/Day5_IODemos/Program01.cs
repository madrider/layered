﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_IODemos
{
    class Program01
    {
        static void Main(string[] args)
        {
            //Using File Class
            //Creating a File

            FileStream fstream= File.Create("SampleText.txt");
            Console.WriteLine(fstream.Name + "Created Successfully");
            fstream.Close();

            //Copying a File
            if (File.Exists(@"D:\SampleText.txt"))
            {
                File.Delete(@"D:\SampleText.txt");
            }
            else
            {
                File.Copy("SampleText.txt", @"D:\SampleText.txt");
            }

            ////Moving a File
            File.Move("SampleText.txt", @"D:\Sample\SampleText.txt");
        }
    }
}
