﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_IODemos
{
    class Program04
    {
        static void Main(string[] args)
        {
            //Reading Data from File using FileStream
            FileStream fstream = 
                new FileStream(@"D:\Sample\Demo.txt",
                FileMode.Open, FileAccess.Read);

            byte[] readdata = new byte[100];

            //reading data from stream
            fstream.Read(readdata, 0, readdata.Length);

            //foreach (byte b in readdata)
            //{
            //    Console.Write(b + "\t");
            //}

            string data = Encoding.ASCII.GetString(readdata);

            Console.WriteLine("Data from file");
            Console.WriteLine(data);

            fstream.Close();
        }
    }
}
