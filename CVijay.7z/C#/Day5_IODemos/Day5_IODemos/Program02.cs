﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Day5_IODemos
{
    class Program02
    {
        static void Main(string[] args)
        {
            //Using DirectoryInfo Class
            DirectoryInfo directory = 
                new DirectoryInfo(@"D:\Sample");

            if (directory.Exists)
            {
                Console.WriteLine("Directory Name = "+directory.Name);
                Console.WriteLine("Full Name = "+directory.FullName);
                Console.WriteLine("Parent Directory = "+directory.Parent.Name);
                Console.WriteLine("Creation Time = "+directory.CreationTime);

                //Retrieving File Details
                FileInfo[] files = directory.GetFiles();
                Console.WriteLine("No of File = "+files.Length);

                foreach (FileInfo file in files)
                {
                    Console.WriteLine(file.Name);
                }

                //Retrieving Directory Details
                DirectoryInfo[] directoies = directory.GetDirectories();
                Console.WriteLine("No of Directories = "+directoies.Length);

                foreach (DirectoryInfo dir in directoies)
                {
                    Console.WriteLine(dir.Name);
                }
            }
            else
            {
                Console.WriteLine("Directory not available...");
            }
        }
    }
}
