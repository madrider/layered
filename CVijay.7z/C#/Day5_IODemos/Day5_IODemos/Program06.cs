﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_IODemos
{
    //Example of BinaryWriter and BinaryReader
    class Program06
    {
        static void Main(string[] args)
        {
            //Writing Data in Binary
            FileStream fstream1 = 
                new FileStream(@"D:\Sample\BinaryData.txt",
                FileMode.Create, FileAccess.Write);
            BinaryWriter bwriter = new BinaryWriter(fstream1);

            bwriter.Write(1001);
            bwriter.Write("Rahul Sharma");
            bwriter.Write(24);
            bwriter.Write(1899.99);
            bwriter.Write(false);

            Console.WriteLine("Binary Data Written Successfully...");
            bwriter.Close();
            fstream1.Close();

            FileStream fstream2 = new 
                FileStream(@"D:\Sample\BinaryData.txt",
                FileMode.Open, FileAccess.Read);
            BinaryReader breader = new BinaryReader(fstream2);

            Console.WriteLine("\n Data From File....");
            Console.WriteLine(breader.ReadInt32());
            Console.WriteLine(breader.ReadString());
            Console.WriteLine(breader.ReadInt32());
            Console.WriteLine(breader.ReadDouble());
            Console.WriteLine(breader.ReadBoolean());

            breader.Close();
            fstream2.Close();
        }
    }
}
