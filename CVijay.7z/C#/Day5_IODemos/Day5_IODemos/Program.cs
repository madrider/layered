﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Day5_IODemos
{
    class Program
    {
        static void Main(string[] args)
        {
            //Using FileInfo class 
            FileInfo file = new FileInfo(@"D:\Sample\Test.txt");
            //FileInfo file = new FileInfo("Day5_IODemos.exe");

            if (file.Exists)
            {
                Console.WriteLine("File Name = " + file.Name);
                Console.WriteLine("Full Name = " + file.FullName);
                Console.WriteLine("File Length = " + file.Length);
                Console.WriteLine("Extension = "+file.Extension);
                Console.WriteLine("Directory Name =" + file.Directory);
                Console.WriteLine("Creation Time = "+file.CreationTime);
                Console.WriteLine("Modified Time = "+file.LastWriteTime);
                Console.WriteLine("Last Access  = "+file.LastAccessTime);
            }
            else
            {
                Console.WriteLine("No file available..");
            }
        }
    }
}
