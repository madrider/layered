﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6_GarbageCollectionDemo
{
    class Sample:IDisposable
    {
        int x;
        public Sample() { }
        public Sample(int x)
        {
            this.x = x;
        }

        public void DisplayNumber()
        {
            Console.WriteLine("X = "+x);
        }

        public void Dispose()
        {
            //Code to free unmanaged resource
            Console.WriteLine("Dispose Method called");

            GC.SuppressFinalize(this);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Sample obj = new Sample(10);
            obj.DisplayNumber();
            obj.Dispose();

            Console.WriteLine("Maximum Generation ="+GC.MaxGeneration);
            Console.WriteLine("Generation of Obj ="+GC.GetGeneration(obj));
            
        }
    }
}
