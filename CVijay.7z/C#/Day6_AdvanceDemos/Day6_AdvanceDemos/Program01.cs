﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace Day6_AdvanceDemos
{
    class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }

    class Manager : Employee
    {
        public int NoOfEmployees { get; set; }
    }

    class Program01
    {
        static List<Manager> GetManagers()
        {
            return new List<Manager>();
        }

        static void Main(string[] args)
        {
            IEnumerable<Manager> ms = GetManagers();
            IEnumerable<Employee> es = ms;
        }
    }
}
