﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace Day6_AdvanceDemos
{
    class Program
    {
        static void Main(string[] args)
        {
            dynamic x, y;

            x = 10;
            y = new object();
            y.Add(10);

            Console.WriteLine("Sum = "+(x+y));
        }
    }
}
