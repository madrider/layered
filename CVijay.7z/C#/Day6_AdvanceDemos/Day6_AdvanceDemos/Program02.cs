﻿using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace Day6_AdvanceDemos
{
    class Program02
    {
        static void Main(string[] args)
        {
            var wordApplication = new 
                Microsoft.Office.Interop.Word.Application();
            wordApplication.Visible = true;
            object missing = System.Reflection.Missing.Value;
            object file = @"d:\mydoc.docx";
            object visible = true;
            object readOnly = false;

            //Classic Way
            //Document aDoc = wordApplication.Documents.Open(ref file, ref missing, ref readOnly,
            //    ref missing, ref missing, ref missing, ref missing,
            //    ref missing, ref missing, ref missing, ref missing,
            //    ref visible, ref missing, ref missing, ref missing,
            //    ref missing);

            var newdoc = wordApplication.Documents.Open(file, ReadOnly: true, Visible: true);
            newdoc.Activate();
        }
    }
}
