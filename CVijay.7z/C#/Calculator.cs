//Calculator Library
using System;

namespace UtilityLibrary
{
public class Calculator
{
	public static int Sum(int x,int y)
	{
		return x+y;
	}

	public static void Square(int x)
	{
		Console.WriteLine("Square ="+(x*x));
	}
}
}